from .settings_dialog import SettingsDialog, sanitize_template_name

######################################
agl: Interface to the Adobe Glyph List
######################################

.. automodule:: fontTools.agl
   :members: toUnicode, UV2AGL, AGL2UV

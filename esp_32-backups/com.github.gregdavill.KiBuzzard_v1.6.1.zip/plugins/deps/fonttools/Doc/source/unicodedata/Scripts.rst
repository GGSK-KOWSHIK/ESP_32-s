#######
Scripts
#######

.. automodule:: fontTools.unicodedata.Scripts
   :inherited-members:
   :members:
   :undoc-members:

.. data:: fontTools.unicodedata.Scripts.NAMES

.. data:: fontTools.unicodedata.Scripts.RANGES

.. data:: fontTools.unicodedata.Scripts.VALUES



######
Blocks
######

.. automodule:: fontTools.unicodedata.Blocks
   :inherited-members:
   :members:
   :undoc-members:

.. data:: fontTools.unicodedata.Blocks.RANGES

.. data:: fontTools.unicodedata.Blocks.VALUES


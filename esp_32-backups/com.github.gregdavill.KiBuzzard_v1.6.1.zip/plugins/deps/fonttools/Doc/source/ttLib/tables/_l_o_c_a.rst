``loca``: Index to Location
---------------------------

.. automodule:: fontTools.ttLib.tables._l_o_c_a
   :inherited-members:
   :members:
   :undoc-members:


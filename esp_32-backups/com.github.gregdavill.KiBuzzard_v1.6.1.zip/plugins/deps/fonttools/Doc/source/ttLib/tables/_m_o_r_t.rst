``mort``: Glyph Metamorphosis Table
-----------------------------------

.. automodule:: fontTools.ttLib.tables._m_o_r_t
   :inherited-members:
   :members:
   :undoc-members:



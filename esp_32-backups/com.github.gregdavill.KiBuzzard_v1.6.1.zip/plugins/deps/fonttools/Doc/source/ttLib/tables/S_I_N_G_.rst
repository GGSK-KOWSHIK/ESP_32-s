``SING``: SING Glyphlet Basic Information Table
-----------------------------------------------

.. automodule:: fontTools.ttLib.tables.S_I_N_G_
   :inherited-members:
   :members:
   :undoc-members:

``EBDT``: Embedded Bitmap Data Table
------------------------------------

.. automodule:: fontTools.ttLib.tables.E_B_D_T_
   :inherited-members:
   :members:
   :undoc-members:


BitmapGlyphMetrics
^^^^^^^^^^^^^^^^^^

.. automodule:: fontTools.ttLib.tables.BitmapGlyphMetrics
   :noindex:
   :inherited-members:
   :members:
   :undoc-members:


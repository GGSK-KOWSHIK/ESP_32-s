``cidg``: CID to Glyph ID table
-------------------------------

.. automodule:: fontTools.ttLib.tables._c_i_d_g
   :inherited-members:
   :members:
   :undoc-members:

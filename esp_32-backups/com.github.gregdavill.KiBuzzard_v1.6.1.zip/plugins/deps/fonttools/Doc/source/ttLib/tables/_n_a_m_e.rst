``name``: Naming Table
----------------------

.. automodule:: fontTools.ttLib.tables._n_a_m_e
   :inherited-members:
   :members:
   :undoc-members:


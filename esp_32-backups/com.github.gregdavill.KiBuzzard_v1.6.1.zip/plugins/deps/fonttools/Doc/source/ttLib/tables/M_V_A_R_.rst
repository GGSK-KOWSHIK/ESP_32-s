``MVAR``: Metrics Variations Table
----------------------------------

.. automodule:: fontTools.ttLib.tables.M_V_A_R_
   :inherited-members:
   :members:
   :undoc-members:

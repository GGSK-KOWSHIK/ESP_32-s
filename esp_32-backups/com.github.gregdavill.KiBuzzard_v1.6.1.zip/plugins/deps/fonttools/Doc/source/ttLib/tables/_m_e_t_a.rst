``meta``: Metadata Table
------------------------

.. automodule:: fontTools.ttLib.tables._m_e_t_a
   :inherited-members:
   :members:
   :undoc-members:


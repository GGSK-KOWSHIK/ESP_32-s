``JSTF``: Justification Table
-----------------------------

.. automodule:: fontTools.ttLib.tables.J_S_T_F_
   :inherited-members:
   :members:
   :undoc-members:

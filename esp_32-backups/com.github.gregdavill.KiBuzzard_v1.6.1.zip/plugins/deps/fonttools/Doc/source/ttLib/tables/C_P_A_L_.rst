``CPAL``: Color Palette Table
-----------------------------

.. automodule:: fontTools.ttLib.tables.C_P_A_L_
   :inherited-members:
   :members:
   :undoc-members:


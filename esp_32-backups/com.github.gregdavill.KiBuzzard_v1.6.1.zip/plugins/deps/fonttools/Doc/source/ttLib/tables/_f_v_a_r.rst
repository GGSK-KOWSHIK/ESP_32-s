``fvar``: Font Variations Table
-------------------------------

.. automodule:: fontTools.ttLib.tables._f_v_a_r
   :inherited-members:
   :members:
   :undoc-members:


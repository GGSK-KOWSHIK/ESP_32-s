``feat``: Feature name table
----------------------------

.. automodule:: fontTools.ttLib.tables._f_e_a_t
   :inherited-members:
   :members:
   :undoc-members:

``sbix``: Standard Bitmap Graphics Table
----------------------------------------

.. automodule:: fontTools.ttLib.tables._s_b_i_x
   :inherited-members:
   :members:
   :undoc-members:



sbixGlyph
^^^^^^^^^

.. automodule:: fontTools.ttLib.tables.sbixGlyph
   :inherited-members:
   :members:
   :undoc-members:

sbixStrike
^^^^^^^^^^

.. automodule:: fontTools.ttLib.tables.sbixStrike
   :inherited-members:
   :members:
   :undoc-members:

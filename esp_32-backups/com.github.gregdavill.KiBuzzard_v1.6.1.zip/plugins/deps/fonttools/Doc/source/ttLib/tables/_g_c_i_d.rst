``gcid``: Glyph ID to CID table
-------------------------------

.. automodule:: fontTools.ttLib.tables._g_c_i_d
   :inherited-members:
   :members:
   :undoc-members:

``TTFA``: ``ttfautohint`` Parameter Table
-----------------------------------------

.. automodule:: fontTools.ttLib.tables.T_T_F_A_
   :inherited-members:
   :members:
   :undoc-members:


``CBLC``: Color Bitmap Location Table
-------------------------------------

.. automodule:: fontTools.ttLib.tables.C_B_L_C_
   :inherited-members:
   :members:
   :undoc-members:


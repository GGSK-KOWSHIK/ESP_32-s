####
sfnt
####

.. automodule:: fontTools.ttLib.sfnt
   :inherited-members:
   :members:
   :undoc-members:

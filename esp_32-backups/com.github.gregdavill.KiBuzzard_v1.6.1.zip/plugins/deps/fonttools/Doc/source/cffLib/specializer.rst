##############################################################
specializer: T2CharString operator specializer and generalizer
##############################################################

.. automodule:: fontTools.cffLib.specializer
   :inherited-members:
   :members:
   :undoc-members:

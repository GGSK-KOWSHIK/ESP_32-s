###########################################
afmLib: Read/write Adobe Font Metrics files
###########################################

.. automodule:: fontTools.afmLib

.. autoclass:: fontTools.afmLib.AFM
   :members:

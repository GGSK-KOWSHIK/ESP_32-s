####
path
####

.. toctree::
   :maxdepth: 1

   parser

.. automodule:: fontTools.svgLib.path
   :inherited-members:
   :members:
   :undoc-members:

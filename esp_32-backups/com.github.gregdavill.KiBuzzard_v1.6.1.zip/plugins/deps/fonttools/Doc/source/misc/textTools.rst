#########
textTools
#########

.. automodule:: fontTools.misc.textTools
   :inherited-members:
   :members:
   :undoc-members:

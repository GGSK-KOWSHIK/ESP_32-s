######################################################
fixedTools: Tools for working with fixed-point numbers
######################################################

.. automodule:: fontTools.misc.fixedTools
   :inherited-members:
   :members:
   :undoc-members:

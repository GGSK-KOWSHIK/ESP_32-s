##########################################################
filenames: Implements UFO User Name to File Name Algorithm
##########################################################

.. automodule:: fontTools.misc.filenames
   :members: userNameToFileName
   :undoc-members:

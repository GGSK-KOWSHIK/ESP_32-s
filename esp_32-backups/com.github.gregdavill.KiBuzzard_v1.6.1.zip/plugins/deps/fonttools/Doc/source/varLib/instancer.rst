#########
instancer
#########

.. automodule:: fontTools.varLib.instancer
   :inherited-members:
   :members:
   :undoc-members:

######
merger
######

.. automodule:: fontTools.varLib.merger
   :inherited-members:
   :members:
   :undoc-members:

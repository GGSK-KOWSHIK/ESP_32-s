#######
builder
#######

.. automodule:: fontTools.varLib.builder
   :inherited-members:
   :members:
   :undoc-members:

########
varStore
########

.. automodule:: fontTools.varLib.varStore
   :inherited-members:
   :members:
   :undoc-members:

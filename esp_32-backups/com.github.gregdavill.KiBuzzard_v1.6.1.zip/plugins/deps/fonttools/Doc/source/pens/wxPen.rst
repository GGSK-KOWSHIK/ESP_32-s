#####
wxPen
#####

.. automodule:: fontTools.pens.wxPen
   :inherited-members:
   :members:
   :undoc-members:

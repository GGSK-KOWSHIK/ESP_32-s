#############
statisticsPen
#############

.. automodule:: fontTools.pens.statisticsPen
   :inherited-members:
   :members:
   :undoc-members:

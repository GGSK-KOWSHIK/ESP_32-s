############
recordingPen
############

.. automodule:: fontTools.pens.recordingPen
   :inherited-members:
   :members:
   :undoc-members:
